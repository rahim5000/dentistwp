        
                            <div class="blog-post">
                                <div class="single-post">

                                    <div class="post-thumb"><img src="<?php the_post_thumbnail_url(); ?>" alt="blog thumb" /></div>
                                    <div class="blog-single-content">
                                        <div class="blog-list-content">
                                            <p class="post-meta">Posted By <a href="#"> <?php the_author(); ?> </a></p>
                                            <h3 class="blog-title"> <?php the_title(); ?> </h3>
																	<?php the_content(); ?>
																	<hr>
                                        </div> <!-- class="blog-list-content" -->                            
									</div> <!-- class="blog-single-content" -->
                                    </div> <!-- class="single-post" -->
                            </div> <!-- class="blog-post" -->
            
        

            
        
