<?php wp_footer(); ?>

<section id="footer-two">
                <div class="container">
                    <ul class="footer-brand">
                        <li>
                            <a href="#"><img src="<?php bloginfo('template_directory'); ?>/media/footer/1.png" alt="brand" /></a>
                        </li>
                        <li>
                            <a href="#"><img src="<?php bloginfo('template_directory'); ?>/media/footer/2.png" alt="brand" /></a>
                        </li>
                        <li>
                            <a href="#"><img src="<?php bloginfo('template_directory'); ?>/media/footer/3.png" alt="brand" /></a>
                        </li>
                        <li>
                            <a href="#"><img src="<?php bloginfo('template_directory'); ?>/media/footer/4.png" alt="brand" /></a>
                        </li>
                    </ul>
                    <p>Dentistry - Copyright 2020 by <a target="_blank" href="">Celine John</a></p>
                </div>
            </section>
            
